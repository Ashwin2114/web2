<?php

require __DIR__ . '/../index.php';
